# Alambda Crash Lab

A browser viewer for the recorded frames and OpenCV detections in [Alambda Crash-Test Vision](https://github.com/Alambdasystem/alambda-crash-test-vision).

The viewer uses all 180 frames from the published source excerpt. WebP sheets are spatially resized and compressed copies of those decoded frames; no temporal frames are generated. Drawing a selected frame and its recorded detection together makes frame stepping deterministic, without depending on approximate video seeking.

## Run the viewer

This is buildless HTML, CSS, and JavaScript. Serve `dist/` with an ordinary static file server. For example, from this project directory:

```bash
python -m http.server 8000 --directory dist
```

Then open `http://localhost:8000`. No API key, model download, or browser inference is required. The included boxes and scores are the recorded results of the original Python pipeline.

## Rebuild the frame assets

Use the Python environment from the upstream project, including OpenCV and Pillow:

```bash
python tools/export_viewer_assets.py --project /path/to/alambda-crash-test-vision --output dist/assets
```

The exporter checks the source video and tracking structure, decodes the source frames, creates the frame sheets, and copies the downloadable example files. Its output is described by `dist/assets/case.json`.

## Create a portable HTML viewer

```bash
python tools/bundle_portable_viewer.py --output /path/to/viewer.html
```

The generated HTML embeds the frame sheets, recorded observations, styles, and viewer logic. Save and open it in a modern browser. Playback, stepping, and overlays work without a server; the community, source, repository, and download links require internet access.

## Interpreting the view

- Frames are zero-based, from 0 through 179. Clip playback rate is 30000/1001 fps; frame 13 is at approximately 0.434 seconds.
- The source was already slow motion. Speed controls are relative to source playback, not physical crash time.
- Frame 13 is a manually reviewed contact marker with uncertainty of ±3 frames: frames 10–16 inclusive. It is distinct from the camera's burned-in time-zero mark near frame 16.
- Boxes and detection scores are recorded model outputs. The trail follows box centers in image space. Deformation changes a box center; it is not a tracked physical landmark.
- The viewer does not estimate physical speed, acceleration, collision force, injury, fault, or causation.

## Credits

Footage: NHTSA, via [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:NHTSA_Crash_Test_of_the_2006_Honda_Ridgeline.ogv), identified there as a U.S. Department of Transportation public-domain work. The excerpt and its provenance are included in the upstream repository. Detection: OpenCV DNN, OpenCV Zoo, and YOLOX. Viewer and Python project: Alambda Systems, Apache License 2.0. See the included license and source attribution files.

[Join the free ArchTek AI community](https://www.skool.com/archtek-ai-6649/about).
