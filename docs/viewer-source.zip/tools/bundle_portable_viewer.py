#!/usr/bin/env python3
"""Bundle the reviewed crash viewer into an HTML file with embedded frames.

The viewer itself needs no server or network connection. Download links point
to the existing public GitHub project and therefore need internet access.
"""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import re


def bundle(dist: Path, output: Path) -> None:
    html = (dist / "index.html").read_text(encoding="utf-8")
    css = (dist / "styles.css").read_text(encoding="utf-8")
    script = (dist / "app.js").read_text(encoding="utf-8")
    case = json.loads((dist / "assets/case.json").read_text(encoding="utf-8"))
    for sheet in case["atlas"]["sheets"]:
        sheet["url"] = "data:image/webp;base64," + base64.b64encode(
            (dist / sheet["url"]).read_bytes()
        ).decode("ascii")
    public_root = "https://github.com/Alambdasystem/alambda-crash-test-vision/blob/main/"
    case["downloads"].update({
        "video": public_root + "docs/demo.mp4?raw=true",
        "code": public_root + "docs/code.zip?raw=true",
        "tracks": public_root + "output/tracks.json?raw=true",
        "source": public_root + "assets/source.json?raw=true",
        "source_video": public_root + "assets/source.mp4?raw=true",
    })
    payload = json.dumps(case, ensure_ascii=False, separators=(",", ":"))
    payload = payload.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    html, css_count = re.subn(
        r'<link\b(?=[^>]*\brel=["\']stylesheet["\'])(?=[^>]*\bhref=["\'](?:\./)?styles\.css["\'])[^>]*>',
        lambda _: "<style>\n" + css + "\n</style>", html, flags=re.IGNORECASE,
    )
    # The original external script uses defer. An inline classic script does
    # not honor defer, so keep only its data in the head and run application
    # logic after the document's controls and canvases have been parsed.
    case_script = '<script id="alambda-crash-case">\nwindow.ALAMBDA_CRASH_CASE=' + payload + ";\n</script>"
    html, js_count = re.subn(
        r'<script\b(?=[^>]*\bsrc=["\'](?:\./)?app\.js["\'])[^>]*>\s*</script>',
        lambda _: case_script, html, flags=re.IGNORECASE,
    )
    if css_count != 1 or js_count != 1:
        raise ValueError(f"Expected one stylesheet and one script: got {css_count}, {js_count}")
    if "window.ALAMBDA_CRASH_CASE" not in script:
        raise ValueError("The application must support embedded case data")
    escaped_script = re.sub(r'</script', lambda _: '<\\/script', script, flags=re.IGNORECASE)
    inline_script = '<script id="alambda-crash-app">\n' + escaped_script + '\n</script>\n'
    html, body_count = re.subn(r'</body\s*>', lambda match: inline_script + match.group(0), html, flags=re.IGNORECASE)
    if body_count != 1:
        raise ValueError(f"Expected one closing body tag; got {body_count}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding="utf-8")
    print(json.dumps({"output": str(output.resolve()), "size_bytes": output.stat().st_size,
                      "embedded_sheets": len(case["atlas"]["sheets"]),
                      "source_frames": case["frame_count"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dist", type=Path, default=Path(__file__).resolve().parents[1] / "dist")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    bundle(args.dist.resolve(), args.output.resolve())
