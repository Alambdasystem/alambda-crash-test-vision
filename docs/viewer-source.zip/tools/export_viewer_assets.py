#!/usr/bin/env python3
"""Export the reviewed NHTSA crash case into real-frame browser assets.

Usage:
    python tools/export_viewer_assets.py \
        --project /path/to/alambda-crash-test-vision --output dist/assets

Requires opencv-python and Pillow. The output is the assets directory, not the
site root. This exporter decodes the source excerpt sequentially, preserves all
180 frames, and resizes them into WebP sprite sheets. It does not interpolate,
generate, or drop temporal frames. The supplied contact annotation belongs only
to this reviewed case; other footage requires a separately reviewed case.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
from pathlib import Path

import cv2
from PIL import Image, features
import PIL


FPS_NUMERATOR = 30000
FPS_DENOMINATOR = 1001
FPS = FPS_NUMERATOR / FPS_DENOMINATOR
WIDTH, HEIGHT, FRAME_COUNT = 1280, 720, 180
TILE_WIDTH, TILE_HEIGHT = 960, 540
COLUMNS, ROWS = 4, 3
FRAMES_PER_SHEET = COLUMNS * ROWS
WEBP_QUALITY = 92

COPIES = {
    "docs/demo.mp4": "demo.mp4",
    "docs/code.zip": "code.zip",
    "output/tracks.json": "tracks.json",
    "assets/source.json": "source.json",
    "assets/source.mp4": "source.mp4",
    "assets/SOURCE_ATTRIBUTION.md": "SOURCE_ATTRIBUTION.md",
    "assets/YOLOX_LICENSE.txt": "YOLOX_LICENSE.txt",
    "LICENSE": "LICENSE",
    "THIRD_PARTY.md": "THIRD_PARTY.md",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def write_json(path: Path, value: dict) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def source_time(index: int) -> float:
    """Clip playback clock, not physical time elapsed during the crash test."""
    return round(index * FPS_DENOMINATOR / FPS_NUMERATOR, 9)


def validate_case(project: Path) -> tuple[dict, dict, dict]:
    for relative in (*COPIES, "output/render_summary.json"):
        if not (project / relative).is_file():
            raise ValueError(f"Missing project input: {relative}")
    source = read_json(project / "assets/source.json")
    tracks = read_json(project / "output/tracks.json")
    render = read_json(project / "output/render_summary.json")
    if source["clip"]["fps_rational"] != "30000/1001":
        raise ValueError("Expected the reviewed source playback rate 30000/1001")
    if source["clip"]["sha256"] != sha256(project / "assets/source.mp4"):
        raise ValueError("Source video does not match its provenance SHA-256")
    for name, expected in (("width", WIDTH), ("height", HEIGHT), ("frames", FRAME_COUNT)):
        if tracks["video"][name] != expected:
            raise ValueError(f"Unexpected tracking metadata: {name}")
    if not math.isclose(tracks["video"]["fps"], FPS, rel_tol=0, abs_tol=1e-9):
        raise ValueError("Tracking playback rate disagrees with source metadata")
    if len(tracks["frames"]) != FRAME_COUNT:
        raise ValueError("Expected exactly 180 tracking records")
    for index, record in enumerate(tracks["frames"]):
        if record["frame"] != index:
            raise ValueError(f"Tracking record {index} has the wrong frame index")
        if abs(record["source_time_s"] - source_time(index)) > 0.00000051:
            raise ValueError(f"Incorrect source playback timestamp at frame {index}")
        for obj in record["objects"]:
            if obj["observation"] != "detected":
                raise ValueError("Only actual detected observations may be exported")
            box, center = obj["bbox"], obj["point"]
            if len(box) != 4 or len(center) != 2:
                raise ValueError("Unexpected box or center coordinate format")
            if not all(math.isfinite(v) for v in (*box, *center, obj["confidence"])):
                raise ValueError("Non-finite detection value")
            if not (0 <= box[0] < box[2] <= WIDTH and 0 <= box[1] < box[3] <= HEIGHT):
                raise ValueError("Detection box falls outside the source image")
            if not (0 <= obj["confidence"] <= 1):
                raise ValueError("Detection score falls outside [0, 1]")
            if any(abs(center[a] - (box[a] + box[a + 2]) / 2) > 0.011 for a in (0, 1)):
                raise ValueError("Recorded point is inconsistent with the box center")
    review = source["contact_review"]
    if review["first_contact_frame"] != 13 or review["uncertainty_frames"] != 3:
        raise ValueError("The reviewed contact annotation has changed; review the viewer case")
    if render["replay"]["end_frame_inclusive"] != 73:
        raise ValueError("The reviewed replay interval has changed")
    return source, tracks, render


def export_sheets(source_path: Path, output: Path) -> list[dict]:
    frames_dir = output / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    capture = cv2.VideoCapture(str(source_path))
    if not capture.isOpened():
        raise ValueError("OpenCV could not open the reviewed source excerpt")
    fps = capture.get(cv2.CAP_PROP_FPS)
    if not math.isclose(fps, FPS, rel_tol=0, abs_tol=1e-6):
        capture.release()
        raise ValueError("Decoded source playback rate does not match 30000/1001")
    sheets, sheet = [], None
    try:
        for index in range(FRAME_COUNT):
            ok, frame = capture.read()
            if not ok:
                raise ValueError(f"Source ended early at frame {index}")
            if frame.shape[:2] != (HEIGHT, WIDTH):
                raise ValueError(f"Source resolution changed at frame {index}")
            tile_index = index % FRAMES_PER_SHEET
            if tile_index == 0:
                sheet = Image.new("RGB", (COLUMNS * TILE_WIDTH, ROWS * TILE_HEIGHT))
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            tile = Image.fromarray(rgb).resize((TILE_WIDTH, TILE_HEIGHT), Image.Resampling.LANCZOS)
            sheet.paste(tile, ((tile_index % COLUMNS) * TILE_WIDTH, (tile_index // COLUMNS) * TILE_HEIGHT))
            if tile_index == FRAMES_PER_SHEET - 1:
                sheet_index = index // FRAMES_PER_SHEET
                name = f"sheet-{sheet_index:02d}.webp"
                target = frames_dir / name
                temporary = frames_dir / (name + ".tmp")
                sheet.save(temporary, format="WEBP", quality=WEBP_QUALITY, method=6, exact=True)
                temporary.replace(target)
                with Image.open(target) as decoded:
                    decoded.load()
                    if decoded.size != (COLUMNS * TILE_WIDTH, ROWS * TILE_HEIGHT):
                        raise ValueError(f"Sprite dimensions are incorrect: {name}")
                sheets.append({
                    "url": f"assets/frames/{name}",
                    "start_frame": index - FRAMES_PER_SHEET + 1,
                    "frame_count": FRAMES_PER_SHEET,
                })
        if capture.read()[0]:
            raise ValueError("Source contains more than the expected 180 frames")
    finally:
        capture.release()
    if len(sheets) != 15:
        raise ValueError("Expected exactly 15 complete sprite sheets")
    return sheets


def export(project: Path, output: Path) -> dict:
    project, output = project.resolve(), output.resolve()
    if output in (project, project / "assets"):
        raise ValueError("Choose a separate viewer assets directory to preserve the project inputs")
    source, tracks, render = validate_case(project)
    output.mkdir(parents=True, exist_ok=True)
    sheets = export_sheets(project / "assets/source.mp4", output)
    for source_relative, destination_relative in COPIES.items():
        shutil.copyfile(project / source_relative, output / destination_relative)
    case = {
        "id": "nhtsa-ridgeline-view07",
        "title": "NHTSA Honda Ridgeline crash test · Camera View-07",
        "width": WIDTH,
        "height": HEIGHT,
        "fps": FPS,
        "frame_count": FRAME_COUNT,
        "contact_frame": source["contact_review"]["first_contact_frame"],
        "contact_uncertainty": source["contact_review"]["uncertainty_frames"],
        "replay_end": render["replay"]["end_frame_inclusive"],
        "detail_crop": [670, 240, 970, 440],
        "frames": [{
            "index": record["frame"],
            "time_s": source_time(record["frame"]),
            "detections": [{
                "track_id": obj["id"],
                "xyxy": obj["bbox"],
                "confidence": obj["confidence"],
                "class_id": obj["class_id"],
                "class_name": obj["class_name"],
                "center": obj["point"],
            } for obj in record["objects"]],
        } for record in tracks["frames"]],
        "atlas": {
            "tile_width": TILE_WIDTH,
            "tile_height": TILE_HEIGHT,
            "columns": COLUMNS,
            "rows": ROWS,
            "frames_per_sheet": FRAMES_PER_SHEET,
            "sheets": sheets,
        },
        "links": {
            "source": source["source_page_url"],
            "repository": "https://github.com/Alambdasystem/alambda-crash-test-vision",
            "community": "https://www.skool.com/archtek-ai-6649/about",
            "youtube": "https://www.youtube.com/shorts/SAH2d-KqmzQ",
        },
        "downloads": {
            "video": "assets/demo.mp4",
            "code": "assets/code.zip",
            "tracks": "assets/tracks.json",
            "source": "assets/source.json",
        },
    }
    write_json(output / "case.json", case)
    (output / "README.md").write_text(
        "# Crash Lab viewer assets\n\n"
        "These assets come from the reviewed Alambda Crash-Test Vision example. "
        "The 15 WebP sheets preserve all 180 recorded source frames in order. "
        "Each sheet is 4 columns × 3 rows; each tile is 960 × 540. "
        "The underlying source and detection coordinates are 1280 × 720.\n\n"
        "Tiles are resized, lossy WebP images at quality 92; they are not new temporal frames. "
        "The original excerpt is available as `source.mp4`. "
        "`demo.mp4` is the 18.6-second edited presentation; use source frames for exact stepping.\n\n"
        "`case.json` supplies the browser case. Frame indices are zero-based. "
        "`time_s` is frame × 1001 / 30000, rounded to 9 decimals. "
        "All clocks and playback speeds refer to an already-slow-motion source file. "
        "The manually reviewed contact marker is frame 13 ±3 (frames 10–16 inclusive). "
        "The camera's burned-in time-zero near frame 16 is a separate reference.\n\n"
        "Detection boxes use `[left, top, right, bottom]` source-image pixels. "
        "Centers are detector box centers, not physical landmarks or a center of mass. "
        "V1 is a temporary within-clip association. "
        "The scores are model outputs and are not measured accuracy. "
        "No physical speed, impact force, causation, or fault is inferred.\n\n"
        "## Reproduce\n\n"
        "Install `opencv-python` and `Pillow`, then run from the site root:\n\n"
        "```sh\npython tools/export_viewer_assets.py --project /path/to/alambda-crash-test-vision --output dist/assets\n```\n\n"
        "The exporter validates source provenance, exact frame count, frame order, "
        "tracking coordinates, playback timestamps, and generated image dimensions. "
        "`manifest.json` records byte counts and SHA-256 hashes without a changing timestamp. "
        "Matching OpenCV, Pillow, and WebP encoder versions are needed for byte-identical WebP regeneration.\n\n"
        "## Attribution and downloads\n\n"
        "Footage: NHTSA via Wikimedia Commons, public domain in the United States. "
        "See `SOURCE_ATTRIBUTION.md`, `source.json`, `THIRD_PARTY.md`, and `YOLOX_LICENSE.txt`. "
        "The original project code is Apache-2.0 (`LICENSE`). "
        "`code.zip` is the published Python code bundle; `tracks.json` is the original tracking output.\n",
        encoding="utf-8",
    )
    generated = ["case.json", "README.md", *COPIES.values(), *[s["url"].removeprefix("assets/") for s in sheets]]
    files = []
    for relative in sorted(generated):
        path = output / relative
        if not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f"Missing or empty output asset: {relative}")
        files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})
    manifest = {
        "schema_version": 1,
        "case_id": case["id"],
        "source_frame_count": FRAME_COUNT,
        "source_fps_rational": "30000/1001",
        "temporal_interpolation": False,
        "tile_size": [TILE_WIDTH, TILE_HEIGHT],
        "sheet_grid": [COLUMNS, ROWS],
        "webp_quality": WEBP_QUALITY,
        "webp_method": 6,
        "encoders": {"opencv": cv2.__version__, "pillow": PIL.__version__, "webp": features.version("webp")},
        "input_source_sha256": sha256(project / "assets/source.mp4"),
        "input_tracks_sha256": sha256(project / "output/tracks.json"),
        "files": files,
        "total_bytes_excluding_manifest": sum(item["bytes"] for item in files),
    }
    write_json(output / "manifest.json", manifest)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True, help="Alambda crash-test-vision project directory")
    parser.add_argument("--output", type=Path, required=True, help="Viewer assets directory, e.g. dist/assets")
    args = parser.parse_args()
    manifest = export(args.project, args.output)
    print(json.dumps({
        "frames": manifest["source_frame_count"],
        "sheets": 15,
        "asset_files_including_manifest": len(manifest["files"]) + 1,
        "total_bytes_including_manifest": manifest["total_bytes_excluding_manifest"] + (args.output / "manifest.json").stat().st_size,
        "output": str(args.output.resolve()),
    }))


if __name__ == "__main__":
    main()
